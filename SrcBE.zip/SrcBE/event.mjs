// --- IMPORT ĐÚNG CHUẨN AWS SDK v3 CommonJS/Esm ---
import pkg_scheduler from "@aws-sdk/client-scheduler";
const { SchedulerClient, CreateScheduleCommand, DeleteScheduleCommand } = pkg_scheduler;
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import * as libddb from "@aws-sdk/lib-dynamodb";
const { DynamoDBDocumentClient, GetCommand, PutCommand, QueryCommand, UpdateCommand, DeleteCommand } = libddb;

// --- CONSTANTS VÀ KHỞI TẠO CLIENT (Tối ưu hóa Cold Start) ---
const TABLE_NAME = "events";

// Khởi tạo SDK Client bên ngoài handler
const ebClient = new SchedulerClient({});
const client = new DynamoDBClient({});
const ddbDocClient = DynamoDBDocumentClient.from(client);

// Lấy ARN và Role ARN từ Biến Môi Trường (YÊU CẦU CẦN CẤU HÌNH)
const REMINDER_LAMBDA_ARN = process.env.REMINDER_LAMBDA_ARN; 
const SCHEDULER_ROLE_ARN = process.env.SCHEDULER_ROLE_ARN; 

// 🔥 HELPER FUNCTION MỚI: KIỂM TRA SỰ KIỆN ĐÃ KẾT THÚC
function isEventInPast(endTimeISO) {
    if (!endTimeISO) return true; 
    const now = new Date();
    const eventEndTime = new Date(endTimeISO);
    return eventEndTime < now;
}

// --- HELPER FORMATTING CHO FRONTEND ---
function formatDateForFE(isoString) {
    if (!isoString) return null;
    try {
        return isoString.substring(0, 10); 
    } catch (e) {
        return isoString;
    }
}

function formatEventItem(item) {
    if (!item) return null;
    return {
        ...item,
        startTime: item.startTime, 
        endTime: item.endTime,     
        createdAt: formatDateForFE(item.createdAt), 
    };
}

// --- GET SCHEDULE NAME HELPER ---
function getScheduleName(userId, eventId) {
    const shortUserId = userId.substring(0, 8);
    const shortEventId = eventId.substring(0, 20); 
    return `event-rem-${shortUserId}-${shortEventId}`;
}

// --- HELPER FUNCTION: Quản lý Schedule (ĐÃ SỬA TIMEZONE) ---

async function scheduleReminder(item) {
    if (!item.userEmail) {
        console.log("SKIP SCHEDULE: userEmail is missing.");
        return { message: "Reminder skipped (missing email)" };
    }
    
    if (!REMINDER_LAMBDA_ARN || !SCHEDULER_ROLE_ARN) {
        const errorMsg = "FATAL: REMINDER_LAMBDA_ARN or SCHEDULER_ROLE_ARN is missing.";
        console.error(errorMsg);
        throw { statusCode: 500, message: errorMsg };
    }
    
    const scheduleName = getScheduleName(item.userId, item.eventId);
    
    const eventTime = new Date(item.startTime);
    // Nhắc nhở 1 giờ trước sự kiện
    const reminderTime = new Date(eventTime.getTime() - 3600 * 1000); 

    if (reminderTime <= new Date()) {
        try {
            await ebClient.send(new DeleteScheduleCommand({ Name: scheduleName, GroupName: "default" }));
            console.log(`Deleted outdated schedule: ${scheduleName}`);
        } catch (e) { /* Bỏ qua */ }
        
        console.log("Event is too soon, not scheduling reminder.");
        return { message: "Reminder skipped (event too soon)" };
    }

    // --- 🔥 UPDATE TIMEZONE LOGIC: VIETNAM TIME (UTC+7) ---
    // Để EventBridge hiểu đúng giờ VN, ta cần truyền chuỗi YYYY-MM-DDTHH:mm:ss
    // tương ứng với giờ mặt đồng hồ tại VN.
    
    // 1. Tạo bản sao thời gian và cộng thêm 7 tiếng (để lấy số giờ VN)
    const vnOffset = 7 * 60 * 60 * 1000;
    const vnTime = new Date(reminderTime.getTime() + vnOffset);
    
    // 2. Lấy chuỗi ISO và cắt bỏ chữ 'Z' ở cuối
    // Ví dụ: reminder thực tế là 09:00 UTC -> vnTime là 16:00 UTC -> chuỗi "2025...T16:00:00"
    const scheduleTime = vnTime.toISOString().substring(0, 19);

    // 1. Kiểm tra và xóa schedule cũ
    try {
        await ebClient.send(new DeleteScheduleCommand({
            Name: scheduleName,
            GroupName: "default"
        }));
        console.log(`Deleted existing schedule: ${scheduleName}`);
    } catch (e) { /* Bỏ qua */ }

    // 2. Tạo Schedule mới với Timezone Asia/Ho_Chi_Minh
    const scheduleCommand = new CreateScheduleCommand({
        Name: scheduleName,
        GroupName: "default",
        ScheduleExpression: `at(${scheduleTime})`, 
        ScheduleExpressionTimezone: "Asia/Ho_Chi_Minh", // 🔥 ĐÃ ĐỔI THÀNH GIỜ VN
        ActionAfterCompletion: "DELETE",
        FlexibleTimeWindow: { Mode: "OFF" },
        Target: {
            Arn: REMINDER_LAMBDA_ARN, 
            Input: JSON.stringify({
                recipientEmail: item.userEmail,
                eventName: item.summary,
                eventTime: item.startTime, 
                eventEndTime: item.endTime
            }),
            RoleArn: SCHEDULER_ROLE_ARN
        }
    });

    await ebClient.send(scheduleCommand);
    console.log(`Scheduled reminder for event ${item.eventId} at ${scheduleTime} (VN Time)`);
    return { message: "Reminder scheduled successfully" };
}


// --- CRUD FUNCTIONS ---

async function createEvent(userId, userEmail, data) {
    if (!data.startTime || !data.endTime) {
        throw { statusCode: 400, message: "Missing required fields: startTime and endTime" };
    }

    const newEventId = "EVT_" + Date.now().toString(36) + Math.random().toString(36).substring(2, 9);
    
    const item = {
        userId: userId,
        eventId: newEventId,
        summary: data.summary || "No summary",
        description: data.description || null,
        startTime: data.startTime,
        endTime: data.endTime,
        googleEventId: data.googleEventId || null,
        userEmail: userEmail || null, 
        createdAt: new Date().toISOString()
    };

    const params = {
        TableName: TABLE_NAME,
        Item: item,
        ConditionExpression: "attribute_not_exists(eventId)" 
    };
    try {
        await ddbDocClient.send(new PutCommand(params));
    } catch (e) {
        if (e.name === 'ConditionalCheckFailedException') {
            throw { statusCode: 409, message: `A unique Event ID could not be generated. Please retry.` };
        }
        throw e;
    }

    try {
        const scheduleResult = await scheduleReminder(item);
        return { message: `Event created. ${scheduleResult.message}`, event: formatEventItem(item) }; 
    } catch (scheduleError) {
        console.error("Failed to schedule reminder:", scheduleError);
        throw { 
            statusCode: scheduleError.statusCode || 500, 
            message: `Event created successfully, but FAILED to schedule reminder: ${scheduleError.message}` 
        };
    }
}

async function readEvent(userId, eventId) {
    if (eventId) {
        const params = {
            TableName: TABLE_NAME,
            Key: { userId: userId, eventId: eventId },
        };
        const response = await ddbDocClient.send(new GetCommand(params));
        if (!response.Item) {
            throw { statusCode: 404, message: "Event not found" };
        }
        return formatEventItem(response.Item); 
    } else {
        const params = {
            TableName: TABLE_NAME,
            KeyConditionExpression: "userId = :uid",
            ExpressionAttributeValues: { ":uid": userId },
        };
        const response = await ddbDocClient.send(new QueryCommand(params));
        return response.Items.map(formatEventItem); 
    }
}

async function updateEvent(userId, eventId, data, currentEmail) {
    const oldEvent = await readEvent(userId, eventId); 
    
    if (isEventInPast(oldEvent.endTime)) {
        throw { statusCode: 403, message: "Forbidden: Cannot update an event that has already ended." };
    }

    const updates = [];
    const expressionAttributeValues = {};
    const expressionAttributeNames = {};
    
    let shouldReschedule = false; 

    for (const key in data) {
        if (key !== 'userId' && key !== 'eventId' && data[key] !== undefined && data[key] !== null) {
            const attrName = `#${key}`;
            const attrValue = `:${key}`;
            updates.push(`${attrName} = ${attrValue}`);
            expressionAttributeValues[attrValue] = data[key];
            expressionAttributeNames[attrName] = key;
            
            if (key === 'startTime' || key === 'endTime' || key === 'summary') {
                shouldReschedule = true;
            }
        }
    }
    
    if (oldEvent.userEmail !== currentEmail) {
        const attrName = `#userEmail`;
        const attrValue = `:userEmail`;
        updates.push(`${attrName} = ${attrValue}`);
        expressionAttributeValues[attrValue] = currentEmail;
        expressionAttributeNames[attrName] = 'userEmail';
    }


    if (updates.length === 0) {
        return { message: "No valid fields to update", event: formatEventItem(oldEvent) };
    }
    
    const params = {
        TableName: TABLE_NAME,
        Key: { userId: userId, eventId: eventId },
        UpdateExpression: "SET " + updates.join(", "),
        ExpressionAttributeValues: expressionAttributeValues,
        ExpressionAttributeNames: expressionAttributeNames,
        ConditionExpression: "attribute_exists(eventId)",
        ReturnValues: "ALL_NEW", 
    };
    
    let response;
    try {
        response = await ddbDocClient.send(new UpdateCommand(params));
    } catch (e) {
        if (e.name === 'ConditionalCheckFailedException') {
            throw { statusCode: 404, message: "Event not found for update" };
        }
        throw e;
    }

    const updatedItem = response.Attributes;
    
    if (shouldReschedule || (!oldEvent.startTime && updatedItem.startTime) || (oldEvent.userEmail !== updatedItem.userEmail)) {
        try {
            await scheduleReminder(updatedItem); 
            return { message: `Event updated and reminder rescheduled.`, event: formatEventItem(updatedItem) };
        } catch(e) {
            console.error("FATAL ERROR: Failed to reschedule reminder:", e);
            throw { statusCode: 500, message: `Event updated successfully, but FAILED to reschedule reminder: ${e.message}` };
        }
    }
    
    return { message: `Event updated. Reminder status unchanged.`, event: formatEventItem(updatedItem) };
}

async function deleteEvent(userId, eventId) {
    const eventToDelete = await readEvent(userId, eventId);
    if (isEventInPast(eventToDelete.endTime)) {
        throw { statusCode: 403, message: "Forbidden: Cannot delete an event that has already ended." };
    }
    
    const scheduleName = getScheduleName(userId, eventId);

    try {
        await ebClient.send(new DeleteScheduleCommand({
            Name: scheduleName,
            GroupName: "default"
        }));
        console.log(`Deleted schedule: ${scheduleName}`);
    } catch (e) {
        console.log(`Schedule ${scheduleName} not found or already deleted`, e.message);
    }

    const params = {
        TableName: TABLE_NAME,
        Key: { userId: userId, eventId: eventId },
        ConditionExpression: "attribute_exists(eventId)",
    };
    try {
        await ddbDocClient.send(new DeleteCommand(params));
    } catch (e) {
         if (e.name === 'ConditionalCheckFailedException') {
             throw { statusCode: 404, message: "Event not found for deletion" };
         }
        throw e;
    }

    return { message: "Event and reminder deleted successfully" };
}

// --- MAIN HANDLER ---
export const handler = async (event) => {
    console.log("Request event:", event);

    let body;
    let statusCode = 200;
    const httpMethod = event?.requestContext?.http?.method;

    let userId, userEmail;
    try {
        const authorizer = event.requestContext?.authorizer;
        const claims = authorizer?.jwt?.claims || authorizer?.claims; 

        if (claims) {
            userId = claims.sub;
            userEmail = claims.email || claims.email_address; 
        } else {
            throw new Error("Authorization context/claims not found.");
        }
        
        if (!userId) {
            throw new Error("User ID (sub claim) not found in token claims."); 
        }
        
    } catch (e) {
        console.error("Authorization error:", e);
        return {
            statusCode: 401,
            body: JSON.stringify({ message: "Unauthorized. Missing or invalid token/claims." }),
            headers: { "Access-Control-Allow-Origin": "*" },
        };
    }

    const eventId = event.pathParameters ? event.pathParameters.eventId : null;

    if (event.body) {
        try {
            body = JSON.parse(event.body);
        } catch (error) {
            return { statusCode: 400, body: JSON.stringify({ message: "Invalid JSON body" }), headers: { "Access-Control-Allow-Origin": "*" } };
        }
    }

    try {
        let responseBody;

        switch (httpMethod) {
            case "OPTIONS":
                return {
                    statusCode: 204, 
                    headers: {
                        "Access-Control-Allow-Origin": "*",
                        "Access-Control-Allow-Methods": "POST, GET, PUT, DELETE, OPTIONS",
                        "Access-Control-Allow-Headers": "Content-Type, Authorization"
                    },
                    body: null,
                };

            case "POST":
                responseBody = await createEvent(userId, userEmail, body);
                statusCode = 201;
                break;

            case "GET":
                responseBody = await readEvent(userId, eventId);
                break;

            case "PUT":
                if (!eventId) throw { statusCode: 400, message: "Missing eventId in path for PUT" };
                responseBody = await updateEvent(userId, eventId, body, userEmail);
                break;

            case "DELETE":
                if (!eventId) throw { statusCode: 400, message: "Missing eventId in path for DELETE" };
                responseBody = await deleteEvent(userId, eventId);
                break;

            default:
                throw new Error(`Unsupported method: ${httpMethod}`);
        }

        return {
            statusCode: statusCode,
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            body: JSON.stringify(responseBody),
        };
    } catch (error) {
        console.error("Error processing request:", error);
        return {
            statusCode: error.statusCode || 500,
            headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
            body: JSON.stringify({ message: error.message || "Internal Server Error" }),
        };
    }
};