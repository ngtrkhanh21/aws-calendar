// --- IMPORT RESEND SDK ---
import { Resend } from 'resend';

// Lấy Resend API Key từ biến môi trường
const RESEND_API_KEY = process.env.RESEND_API_KEY;

// Sử dụng domain đã được xác thực của bạn: auroratime.click
const FROM_EMAIL = process.env.FROM_EMAIL || "no-reply@auroratime.click"; 

// --- TỐI ƯU HÓA: Khởi tạo Resend ngoài handler để tái sử dụng (warm start) ---
let resend;
if (RESEND_API_KEY) {
    resend = new Resend(RESEND_API_KEY);
}

// 🔥 [ĐÃ SỬA] HELPER MỚI: Định dạng giờ VN (Asia/Ho_Chi_Minh)
const formatTimeDisplay = (isoString) => {
    if (!isoString) return 'N/A';
    try {
        return new Intl.DateTimeFormat('en-GB', {
            timeZone: 'Asia/Ho_Chi_Minh',
            hour: '2-digit',
            minute: '2-digit',
            hour12: false 
        }).format(new Date(isoString));
    } catch (e) {
        return 'Invalid Time';
    }
};

// 🔥 [ĐÃ SỬA] HELPER MỚI: Định dạng ngày VN (Asia/Ho_Chi_Minh)
const formatDateDisplay = (isoString) => {
    if (!isoString) return 'N/A';
    try {
        // en-CA format ra YYYY-MM-DD giống format cũ của bạn
        return new Intl.DateTimeFormat('en-CA', { 
            timeZone: 'Asia/Ho_Chi_Minh',
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        }).format(new Date(isoString));
    } catch (e) {
        return 'Invalid Date';
    }
};


// Hàm trợ giúp tạo slug cho Tags (Logic không đổi)
const slugify = (text) => {
    if (!text) return '';
    return text
        .toString().toLowerCase()
        .replace(/\s+/g, '-') 
        .replace(/[^\w\-]+/g, '') 
        .replace(/\-\-+/g, '-') 
        .replace(/^-+/, '') 
        .replace(/-+$/, ''); 
};

export const handler = async (event) => {
    console.log("EventBridge Scheduler đã kích hoạt, nhận được sự kiện:", event);

    // Lấy dữ liệu từ event (lưu ý tên biến phải khớp với payload gửi lên)
    // Payload của bạn dùng: description, startTime, endTime, summary
    // Nhưng code cũ của bạn đang dùng: recipientEmail, eventName, eventTime
    // -> Mình sẽ map lại cho an toàn hoặc bạn cần sửa payload gửi lên cho khớp.
    // Dưới đây mình map theo Payload JSON bạn gửi lúc nãy:
    
    const recipientEmail = event.userEmail || event.recipientEmail;
    const eventName = event.summary || event.eventName || "No Title";
    const eventTime = event.startTime || event.eventTime;
    const eventEndTime = event.endTime || event.eventEndTime;
    const description = event.description || "";

    // 🔥 BƯỚC MỚI: ĐỊNH DẠNG LẠI THỜI GIAN CHO EMAIL
    // Lúc này nó sẽ convert UTC -> GMT+7
    const displayTime = formatTimeDisplay(eventTime);      
    const displayEndTime = formatTimeDisplay(eventEndTime); 
    const displayDate = formatDateDisplay(eventTime);       
    
    // 1. Kiểm tra tham số và Resend instance
    if (!recipientEmail || !eventTime) {
        throw new Error("Missing required event data (email or time).");
    }

    if (!resend) {
        console.error("ERROR: RESEND_API_KEY environment variable is not set.");
        throw new Error("RESEND_API_KEY is not configured. Skipping email send."); 
    }
    
    // BỔ SUNG: Xác thực email cơ bản
    const emailRegex = /\S+@\S+\.\S+/;
    if (!emailRegex.test(recipientEmail)) {
        console.error(`Invalid recipient email format: ${recipientEmail}`);
        throw new Error(`Invalid recipient email format: ${recipientEmail}`);
    }

    // 2. Tạo nội dung email (Text và HTML)
    const subject = `Reminder: Your event "${eventName}" is starting in 1 hour.`;
    
    const bodyText = `Hello,\n\nThis is a reminder that your event, "${eventName}", is scheduled to begin in 1 hour.\n\nEvent Details:\n- Date: ${displayDate}\n- Starts at: ${displayTime}\n- Ends at: ${displayEndTime}\n\nWe hope you have a great event!\n\nBest,\nThe AuroraTime Team (via Resend)`;
    
    const bodyHtml = `
        <div style="font-family: sans-serif; padding: 20px; border: 1px solid #eee;">
            <h2>🔔 Reminder: ${eventName}</h2>
            <p>Hello,</p>
            <p>This is a reminder that your event, <strong>${eventName}</strong>, is scheduled to begin in <strong>1 hour</strong>.</p>
            <p><em>${description}</em></p>
            <table style="border-collapse: collapse; margin: 15px 0;">
                <tr>
                    <td style="padding: 5px; border: 1px solid #ccc; background-color: #f9f9f9;">Date:</td>
                    <td style="padding: 5px; border: 1px solid #ccc;">${displayDate}</td>
                </tr>
                <tr>
                    <td style="padding: 5px; border: 1px solid #ccc; background-color: #f9f9f9;">Starts at:</td>
                    <td style="padding: 5px; border: 1px solid #ccc;">${displayTime}</td>
                </tr>
                <tr>
                    <td style="padding: 5px; border: 1px solid #ccc; background-color: #f9f9f9;">Ends at:</td>
                    <td style="padding: 5px; border: 1px solid #ccc;">${displayEndTime}</td>
                </tr>
            </table>
            <p>We hope you have a great event!</p>
            <p>Best,<br>The AuroraTime Team (via Resend)</p>
        </div>
    `;

    // 3. Chuẩn bị lệnh gửi mail Resend
    const sendEmailParams = {
        from: `AuroraTime Reminders <${FROM_EMAIL}>`,
        to: [recipientEmail],
        subject: subject,
        text: bodyText,
        html: bodyHtml, 
        tags: [
            {
                name: 'category', 
                value: 'event-reminder', 
            },
            {
                name: 'event-name-slug', 
                value: slugify(eventName),
            }
        ]
    };

    // 4. Gửi email
    try { 
        const response = await resend.emails.send(sendEmailParams);
        
        if (response.error) {
            console.error('Resend API Error:', response.error);
            throw new Error(`Resend API failed: ${response.error.message}`); 
        }

        console.log(`Successfully sent email to ${recipientEmail} (Resend ID: ${response.data.id})`);
        return {
            statusCode: 200,
            body: JSON.stringify({ message: "Email sent successfully via Resend.", id: response.data.id }),
        };
    } catch (error) {
        console.error("Lambda Execution Error:", error);
        throw error; 
    }
};