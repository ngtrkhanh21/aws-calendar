// --- IMPORT ---
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { 
  DynamoDBDocumentClient, 
  PutCommand, 
  QueryCommand, 
  GetCommand, 
  UpdateCommand, 
  DeleteCommand 
} from "@aws-sdk/lib-dynamodb";
import { randomUUID } from "crypto"; 

// --- CONFIG ---
const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);
const TABLE_NAME = process.env.TABLE_NAME || "todo";

// --- VALID LIST ---
const VALID_RECURRENCE = ['NONE', 'DAILY', 'WEEKLY', 'MONTHLY', 'WEEKDAY', 'YEARLY'];

// ---------------------------------
// HANDLER CHÍNH
// ---------------------------------
export const handler = async (event) => {
  console.log("Request:", JSON.stringify(event));

  try { 
    // 1. Auth Check
    const userId = event.requestContext.authorizer?.jwt?.claims?.sub;
    if (!userId) return createResponse(401, { message: "Unauthorized: Missing sub claim" });

    // 2. Parse Info
    const method = event.requestContext.http.method; 
    const todoId = event.pathParameters?.todoId || null;
    
    let body = null;
    if (event.body) {
        try { body = JSON.parse(event.body); } 
        catch (e) { return createResponse(400, { message: "Invalid JSON" }); }
    }

    // 3. Router
    switch (method) {
      case 'OPTIONS': return createResponse(204, null);
      case 'POST':    return await createTodo(userId, body);
      case 'GET':     
        return todoId ? await getTodo(userId, todoId) : await getAllTodos(userId);
      case 'PUT':     
        if (!todoId) throw new ValidationError("todoId required");
        return await updateTodo(userId, todoId, body);
      case 'DELETE':  
        if (!todoId) throw new ValidationError("todoId required");
        return await deleteTodo(userId, todoId);
      default: return createResponse(405, { message: `Method ${method} Not Allowed` });
    }
  } catch (error) {
    console.error("Handler Error:", error);
    if (error.name === 'ValidationError') return createResponse(400, { message: error.message });
    return createResponse(500, { message: "Internal Server Error", error: error.message });
  }
};

// ---------------------------------
// LOGIC CRUD (LƯU TRỮ RECURRENCE)
// ---------------------------------

async function createTodo(userId, data) {
  // 1. Validation cơ bản
  if (!data || !data.taskName || !data.dateTime || !data.endTime) {
    throw new ValidationError("Missing required fields: taskName, dateTime, endTime");
  }

  // 2. Xử lý Recurrence (Quy ước dữ liệu FE gửi lên)
  // Mặc định là 'NONE' nếu FE không gửi
  let recurrence = data.recurrence || 'NONE'; 
  
  // Validate giá trị recurrence có nằm trong list cho phép không
  if (!VALID_RECURRENCE.includes(recurrence)) {
      throw new ValidationError(`Invalid recurrence type. Must be one of: ${VALID_RECURRENCE.join(', ')}`);
  }

  // Backend không cần tính toán "Thứ mấy" hay "Ngày nào" để lưu riêng,
  // vì FE có thể tự suy ra từ trường `recurrence` kết hợp với `dateTime`.
  // Ví dụ: dateTime="2025-12-08" (Thứ 2) + recurrence="WEEKLY" -> Tự hiểu là Thứ 2 hàng tuần.

  const todoId = randomUUID(); 
  const item = {
    userId: userId,
    todoId: todoId,
    taskName: data.taskName,
    description: data.description || "",
    
    dateTime: data.dateTime, // Start Time
    endTime: data.endTime,   // End Time (trong ngày)
    
    // --- LƯU THÔNG TIN LẶP LẠI ---
    recurrence: recurrence, 
    recurrenceEnd: data.recurrenceEnd || null, // Ngày kết thúc lặp (nếu có)
    
    isCompleted: false,
    createdAt: new Date().toISOString(),
  };

  const command = new PutCommand({
    TableName: TABLE_NAME,
    Item: item,
  });
  
  await docClient.send(command);
  return createResponse(201, item);
}

async function updateTodo(userId, todoId, data) {
  // Check tồn tại
  const oldItemRes = await docClient.send(new GetCommand({ TableName: TABLE_NAME, Key: { userId, todoId } }));
  if (!oldItemRes.Item) return createResponse(404, { message: "Todo not found" });

  // Lọc các field hợp lệ
  const allowedUpdates = Object.keys(data).filter(k => 
      k !== 'userId' && k !== 'todoId' && k !== 'createdAt' && data[k] !== undefined
  );

  if (allowedUpdates.length === 0) throw new ValidationError("No valid fields to update.");

  // Validate nếu có update recurrence
  if (data.recurrence && !VALID_RECURRENCE.includes(data.recurrence)) {
      throw new ValidationError(`Invalid recurrence type. Must be one of: ${VALID_RECURRENCE.join(', ')}`);
  }

  const command = new UpdateCommand({
    TableName: TABLE_NAME,
    Key: { userId, todoId },
    UpdateExpression: "SET " + allowedUpdates.map(k => `#${k} = :${k}`).join(", "),
    ExpressionAttributeNames: allowedUpdates.reduce((acc, k) => ({ ...acc, [`#${k}`]: k }), {}),
    ExpressionAttributeValues: allowedUpdates.reduce((acc, k) => ({ ...acc, [`:${k}`]: data[k] }), {}),
    ReturnValues: "ALL_NEW", 
  });

  const res = await docClient.send(command);
  return createResponse(200, res.Attributes);
}

// --- CÁC HÀM GET/DELETE GIỮ NGUYÊN (VÌ CHỈ TÁC ĐỘNG DB) ---

async function getAllTodos(userId) {
  const command = new QueryCommand({
    TableName: TABLE_NAME,
    KeyConditionExpression: "userId = :userId",
    ExpressionAttributeValues: { ":userId": userId },
  });
  const res = await docClient.send(command);
  return createResponse(200, res.Items || []);
}

async function getTodo(userId, todoId) {
  const res = await docClient.send(new GetCommand({
    TableName: TABLE_NAME,
    Key: { userId, todoId },
  }));
  return res.Item ? createResponse(200, res.Item) : createResponse(404, { message: "Not found" });
}

async function deleteTodo(userId, todoId) {
  try {
      await docClient.send(new DeleteCommand({
        TableName: TABLE_NAME,
        Key: { userId, todoId },
        ConditionExpression: "attribute_exists(todoId)", 
      }));
      return createResponse(200, { message: "Deleted successfully" });
  } catch (error) {
      if (error.name === 'ConditionalCheckFailedException') return createResponse(404, { message: "Todo not found" });
      throw error;
  }
}

// ---------------------------------
// UTILS
// ---------------------------------
function createResponse(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*", 
      "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
    body: body ? JSON.stringify(body) : "",
  };
}

class ValidationError extends Error {
  constructor(message) {
    super(message);
    this.name = "ValidationError";
  }
}