// Lambda: login-auth-token
// File: index.mjs
// FINAL WORKING VERSION with proper response format

import { SecretsManagerClient, GetSecretValueCommand } from "@aws-sdk/client-secrets-manager";

const secretsClient = new SecretsManagerClient({ region: "ap-southeast-1" });
let cachedSecret = null;

// CORS headers - MUST be present in ALL responses
const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
  'Access-Control-Allow-Methods': 'POST,OPTIONS,GET',
  'Content-Type': 'application/json'
};

// Get credentials from AWS Secrets Manager
async function getSecret() {
  if (cachedSecret) {
    console.log('Using cached secret');
    return cachedSecret;
  }

  try {
    const response = await secretsClient.send(
      new GetSecretValueCommand({
        SecretId: "cognito/auth-config"
      })
    );

    cachedSecret = JSON.parse(response.SecretString);
    console.log('✅ Secret loaded successfully');
    return cachedSecret;
  } catch (error) {
    console.error('❌ Error loading secret:', error);
    throw new Error('Failed to load credentials from Secrets Manager');
  }
}

// Exchange authorization code for tokens
async function exchangeCodeForTokens(code, redirectUri, clientId, clientSecret, cognitoDomain) {
  const tokenEndpoint = `https://${cognitoDomain}/oauth2/token`;
  
  const params = new URLSearchParams({
    grant_type: 'authorization_code',
    client_id: clientId,
    client_secret: clientSecret,
    code: code,
    redirect_uri: redirectUri
  });

  console.log('Calling Cognito token endpoint:', tokenEndpoint);
  console.log('Request params:', {
    grant_type: 'authorization_code',
    client_id: clientId,
    redirect_uri: redirectUri,
    code: code.substring(0, 20) + '...'
  });

  try {
    const response = await fetch(tokenEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: params.toString()
    });

    const data = await response.json();

    if (!response.ok) {
      console.error('❌ Cognito error response:', data);
      throw new Error(`Cognito returned ${response.status}: ${JSON.stringify(data)}`);
    }

    console.log('✅ Tokens received from Cognito');
    console.log('Token types:', Object.keys(data));
    
    // ✅ CRITICAL: Transform to camelCase for frontend
    return {
      accessToken: data.access_token,
      idToken: data.id_token,
      refreshToken: data.refresh_token,
      expiresIn: data.expires_in,
      tokenType: data.token_type || 'Bearer'
    };

  } catch (error) {
    console.error('❌ Fetch error:', error);
    throw error;
  }
}

// Main handler
export const handler = async (event) => {
  console.log('=== Token Exchange Handler Started ===');
  console.log('Event type:', event.requestContext?.http?.method || event.httpMethod || 'unknown');

  // Handle OPTIONS preflight for CORS
  const requestMethod = event.requestContext?.http?.method || event.httpMethod;
  if (requestMethod === 'OPTIONS') {
    console.log('✅ Handling OPTIONS preflight');
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  try {
    // Parse request body - support both HTTP API v2.0 and REST API
    let body;
    if (event.body) {
      if (typeof event.body === 'string') {
        body = JSON.parse(event.body);
      } else {
        body = event.body;
      }
    } else {
      // Fallback for direct invocation
      body = event;
    }

    console.log('Parsed body keys:', Object.keys(body));

    const { code, redirectUri } = body;

    if (!code) {
      console.error('❌ Missing authorization code');
      return {
        statusCode: 400,
        headers: CORS_HEADERS,
        body: JSON.stringify({ 
          error: 'missing_code',
          message: 'Authorization code is required'
        })
      };
    }

    if (!redirectUri) {
      console.error('❌ Missing redirect URI');
      return {
        statusCode: 400,
        headers: CORS_HEADERS,
        body: JSON.stringify({ 
          error: 'missing_redirect_uri',
          message: 'Redirect URI is required'
        })
      };
    }

    console.log('Request params:', { 
      code: code.substring(0, 20) + '...',
      redirectUri 
    });

    // Get credentials from Secrets Manager
    console.log('Loading credentials from Secrets Manager...');
    const secrets = await getSecret();

    // Exchange code for tokens
    console.log('Exchanging authorization code for tokens...');
    const tokens = await exchangeCodeForTokens(
      code,
      redirectUri,
      secrets.COGNITO_CLIENT_ID,
      secrets.COGNITO_CLIENT_SECRET,
      secrets.COGNITO_DOMAIN
    );

    console.log('✅ Token exchange successful');
    console.log('Returning tokens with keys:', Object.keys(tokens));

    // ✅ CRITICAL: Return proper JSON response
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: JSON.stringify(tokens)
    };

  } catch (error) {
    console.error('❌ Error in handler:', error);
    
    // Parse error details
    let errorMessage = error.message;
    let errorCode = 'token_exchange_failed';
    let statusCode = 500;

    if (errorMessage.includes('400')) {
      errorCode = 'invalid_grant';
      errorMessage = 'Invalid authorization code. It may have expired or been used already.';
      statusCode = 400;
    } else if (errorMessage.includes('401') || errorMessage.includes('unauthorized')) {
      errorCode = 'invalid_client';
      errorMessage = 'Client authentication failed. Check client secret.';
      statusCode = 401;
    }

    return {
      statusCode,
      headers: CORS_HEADERS,
      body: JSON.stringify({ 
        error: errorCode,
        message: errorMessage,
        details: error.message
      })
    };
  }
};